# Apache Hadoop Test Application

A Simple **Apache Hadoop** application created for testing the **Assignment Submission Portal** for **Distributed Computing Lab** at **Motilal Nehru National Institute Of Technology**. This application reads a huge text file namely **data.txt** and prints the count of each word in that file.

To run this application run the following command -

```
chmod +x hadoop-test.sh
./hadoop-test.sh
```
