# Apache Spark Test Application

A Simple **Apache Spark** application created for testing the **Assignment Submission Portal** for **Distributed Computing Lab** at **Motilal Nehru National Institute Of Technology**. This application reads a huge text file namely **data.txt** and prints the count of lines having character 'a'  and 'b'

To run this application run the following command -

```
spark-submit SparkApp.py
```
